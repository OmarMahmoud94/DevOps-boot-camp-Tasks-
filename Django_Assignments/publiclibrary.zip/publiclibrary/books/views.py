from django.http.response import HttpResponse
from django.shortcuts import redirect, render
from .models import Book

# Create your views here.

def home(request):
    # list books from DB
    books = Book.objects.all()
    print(books[0].photo)
    # render books on the thml page
    return render(request, 'book/index.html', {
        'all_books' : books
    })
    # return HttpResponse('Hello from Books index page')


def read(request):
    return HttpResponse('Hello from Read page.')


def index(request):
    books = Book.objects.all()
    return render(request, 'home/index.html', {
        'all_books' : books
    })

def create_book(request):
    return render(request, 'book/create.html')

def save_book(request):
    # validate request method : POST 
    if request.method == "POST":
        print(request.POST)
        book_name = request.POST.get('book_name')
        book_description = request.POST.get('book_desc')
        book_price = request.POST.get('book_price')
        book_photo = request.FILES.get('myfile')
     
        if (book_name == '') or (book_description == '') or (book_price == ''):  
            return HttpResponse('invalid request : all fields MUST be filled')
        if (book_description.isdigit() == True)  : 
            return HttpResponse('invalid request : description Must be text')
        for book in Book.objects.all():
            if book.name == book_name : 
                return HttpResponse('this book is aleady exist') 
        if int(book_price) <= 0 : 
            return HttpResponse('price Must be greater than 0')
        
        Book.objects.create(
            name=book_name, 
            description=book_description,
            price=book_price,
            photo=book_photo
        )

        return redirect('book-list')

    return HttpResponse('invalid request')

def edit_book(request, book_id):
    # get book old data from db:
    book = Book.objects.get(pk=book_id)
    return render(request, 'book/edit.html', {
        'book_data' : book
    })

def delete_book(request, book_id):
    Book.objects.get(pk=book_id).delete()

    return redirect('book-list')

def new_save(request,book_id):
    if request.method == "POST":
        edited_book = Book()
        edited_book.id = book_id
        edited_book.name = request.POST.get('book_name')
        edited_book.description = request.POST.get('book_desc')
        edited_book.price = request.POST.get('book_price')
        edited_book.save()
        return redirect('book-list')

# Bulk delete 
def delete_bulk(request):
    if request.method == "POST":  
        b_id = request.POST.getlist('book_id') 
        Book.objects.filter(pk__in=b_id).delete()
        return redirect('book-list')
    return HttpResponse('invalid request')
    
def cut(request):
    print('thanks')