from django.urls import path
from .views import home, read, index, create_book, save_book, edit_book, delete_book, new_save, delete_bulk,cut

urlpatterns = [
    path('list', home, name='book-list'),
    path('read', read),
    path('', index,name='home-page'),
    path('create', create_book, name='create-book'),
    path('save', save_book, name='save-book'),
    path('edit/<book_id>', edit_book, name='edit-book'),
    path('delete/<book_id>', delete_book, name='delete-book'),
    path('new_save/<book_id>',new_save,name='new-save-book'),
    path('delete_bulk', delete_bulk, name='delete-bulk'),
]

