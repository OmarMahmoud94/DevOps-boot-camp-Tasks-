from django.apps import AppConfig


class HrsystemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hrsystem'
